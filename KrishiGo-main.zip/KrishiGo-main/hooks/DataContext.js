import { useNavigation } from '@react-navigation/native';
import { doc, getDoc } from 'firebase/firestore';
import { createContext, useEffect, useState } from 'react';
import { getAllCourses } from '../api/courses/all_courses_service';
import { getUserWishlist } from '../api/user/user_service';
import { auth, db } from '../config/firebase';


export const DataContext = createContext();

// ✅ Sample fallback data based on your schema
const sampleCourse = {
    title: "How to Harvest More Effectively",
    description: "Learn how to harvest crops more efficiently and sell them for higher profits.",
    category: "Agriculture",
    level: "Beginner",
    duration: 420, // 7 hours in minutes
    price: 500,
    thumbnail: "https://example.com/course-thumbnail.jpg",
    videoUrl: "https://example.com/course-intro.mp4",
    instructor: {
        name: "John Doe",
        bio: "An expert in organic farming with 10+ years of experience.",
        profilePicture: "https://example.com/johndoe.jpg"
    },
    ratings: {
        average: 4.5,
        totalRatings: 120
    },
    points: 1000
};

const sampleModules = [
    {
        id: "moduleId1",
        courseId: "courseId",
        title: "Introduction",
        description: "In this module, you will learn the basics of harvesting.",
        type: "video",
        videoUrl: "https://example.com/module1.mp4",
        duration: "6 min",
        completed: true,
        order: 1
    },
    {
        id: "moduleId2",
        courseId: "courseId",
        title: "Advanced Techniques",
        description: "Learn advanced techniques for harvesting crops.",
        type: "video",
        videoUrl: "https://example.com/module2.mp4",
        duration: "12 min",
        completed: false,
        order: 2
    },
    {
        id: "moduleId3",
        courseId: "courseId",
        title: "Advanced Techniques Quiz",
        description: "Test your knowledge with a comprehensive quiz.",
        type: "quiz",
        quizId: "jhbfjhsebuhwe",
        duration: "Quiz",
        completed: false,
        order: 3
    },
    {
        id: "moduleId4",
        courseId: "courseId",
        title: "Best Practices",
        description: "Learn the best practices for effective harvesting.",
        type: "video",
        videoUrl: "https://example.com/module4.mp4",
        duration: "8 min",
        completed: false,
        order: 4
    },
    {
        id: "moduleId5",
        courseId: "courseId",
        title: "Final dtfg",
        description: "Complete the final quiz to earn your certificate.",
        type: "quiz",
        quizId: "finalquizid123",
        duration: "Quiz",
        completed: false,
        order: 5
    }
];

// Sample course data
const sampleAllCourses = [
    {
        id: 1,
        title: 'Organic Farming Basics',
        instructor: 'Dr. Rajesh Kumar',
        duration: '4 weeks',
        rating: 4.8,
        image: require('../assets/images/courses/organic-basics.jpg'),
        category: 'Organic',
        level: 'Beginner',
        description: 'Learn the fundamentals of organic farming practices and sustainable agriculture.'
    },
    {
        id: 2,
        title: 'Modern Irrigation Techniques',
        instructor: 'Prof. Meera Sharma',
        duration: '6 weeks',
        rating: 4.9,
        image: require('../assets/images/courses/modern-irrigation.jpg'),
        category: 'Technology',
        level: 'Intermediate',
        description: 'Master water-efficient irrigation systems and smart farming technologies.'
    },
    {
        id: 3,
        title: 'Crop Disease Management',
        instructor: 'Dr. Anil Verma',
        duration: '5 weeks',
        rating: 4.7,
        image: require('../assets/images/courses/crop-disease.jpg'),
        category: 'Health',
        level: 'Advanced',
        description: 'Identify, prevent, and treat common crop diseases using sustainable methods.'
    },
    {
        id: 4,
        title: 'Sustainable Livestock Farming',
        instructor: 'Dr. Priya Patel',
        duration: '8 weeks',
        rating: 4.6,
        image: require('../assets/images/courses/sustainable-livestock.jpg'),
        category: 'Livestock',
        level: 'Intermediate',
        description: 'Ethical and sustainable practices for modern livestock management.'
    },
    {
        id: 5,
        title: 'Soil Health & Nutrition',
        instructor: 'Prof. Suresh Reddy',
        duration: '3 weeks',
        rating: 4.9,
        image: require('../assets/images/courses/soil-health.jpg'),
        category: 'Soil',
        level: 'Beginner',
        description: 'Understanding soil composition, testing, and nutrient management.'
    },
    {
        id: 6,
        title: 'Precision Agriculture',
        instructor: 'Dr. Kavita Singh',
        duration: '7 weeks',
        rating: 4.8,
        image: require('../assets/images/courses/precision-agriculture.jpg'),
        category: 'Technology',
        level: 'Advanced',
        description: 'Use AI, IoT, and data analytics for precision farming solutions.'
    }
];

// Sample rewards
const SampleRewardTasks = [
    {
        id: 1,
        task: 'Plant tree saplings',
        farmerPoints: 1120,
        helperPoints: 460,
        completedBy: null, // 'farmer' | 'helper'
        category: 'Afforestation',
        description: 'Either farmer or youngster can plant saplings. Farmer gets higher reward.'
    },
    {
        id: 2,
        task: 'Adopt drip irrigation',
        farmerPoints: 1180,
        helperPoints: 590,
        completedBy: null,
        category: 'Water Conservation',
        description: 'If farmer installs drip irrigation, more points. Helper gets fewer points for assisting or suggesting.'
    },
    {
        id: 3,
        task: 'Prepare organic compost',
        farmerPoints: 1140,
        helperPoints: 470,
        completedBy: null,
        category: 'Soil Health',
        description: 'Both farmer and helper can create compost, but farmer gets extra points.'
    },
    {
        id: 4,
        task: 'Practice crop rotation',
        farmerPoints: 1160,
        helperPoints: 480,
        completedBy: null,
        category: 'Sustainable Farming',
        description: 'Farmer gets more points for implementing crop rotation. Helper gets less for awareness work.'
    },
    {
        id: 5,
        task: 'Use bio-pesticides instead of chemicals',
        farmerPoints: 1150,
        helperPoints: 475,
        completedBy: null,
        category: 'Eco-Friendly Practices',
        description: 'Farmer applies bio-pesticides in field. Helper gets points if they promote it.'
    },
    {
        id: 6,
        task: 'Install solar-powered pump',
        farmerPoints: 2220,
        helperPoints: 1000,
        completedBy: null,
        category: 'Renewable Energy',
        description: 'Farmer earns more for installing pump. Helper earns less if just promoting/assisting.'
    }
];


const DataProvider = ({ children }) => {

    const navigation = useNavigation();

    const user = auth.currentUser;


    const [loading, setLoading] = useState({
        courseDetails: true,
        modules: true,
        enrolling: false,
        allCourses: false
    });

    const [wishlistedCourses, setWishlistedCourses] = useState([]);

    const [userDetails, setUserDetails] = useState(null);

    const fetchUserDetails = async () => {
        try {
            const user = auth.currentUser;
            if (!user) {
                return;
            }

            const userDoc = await getDoc(doc(db, "users", user.uid));
            if (userDoc.exists()) {
                const userData = userDoc.data();
                setUserDetails(userData);
                // console.log("Fetched user details:", userData);
            } else {
                // Fallback to display name from auth if no Firestore doc exists
                setUserDetails({
                    name: user.displayName?.split(" ")[0] || "User",
                    email: "No email",
                    phone: "No phone",
                });
            }
        } catch (error) {
            console.log("Error fetching user details:", error);
            setUserDetails({
                name: "User",
                email: "No email",
                phone: "No phone",
            });
        }
    };

    const fetchWishlist = async (userId) => {
        try {
            const wishlists = await getUserWishlist(userId);
            const courseIdsForWishlist = wishlists.map(wl => wl.courseId);
            setWishlistedCourses(courseIdsForWishlist);
        } catch (error) {
            console.log("Error fetching user wishlist:", error);
            setWishlistedCourses([]);
        }
    };

    useEffect(() => {
        fetchUserDetails();
    }, []);

    useEffect(() => {
        if (user) {
            fetchWishlist(user.uid);
        }
    }, [user]);

    // -----------------------------------------------------------------------------
    // ------------- All Course State & Methods -------------
    // -----------------------------------------------------------------------------

    const [allCourses, setAllCourses] = useState([]);

    const getCourseImage = (courseId) => {
        // Map course IDs to local images
        const courseImages = {
            "1": require('../assets/images/courses/organic-basics.jpg'),
            "2": require('../assets/images/courses/modern-irrigation.jpg'),
            "3": require('../assets/images/courses/crop-disease.jpg'),
            "4": require('../assets/images/courses/sustainable-livestock.jpg'),
            "5": require('../assets/images/courses/soil-health.jpg'),
            "6": require('../assets/images/courses/precision-agriculture.jpg'),
        };
        return courseImages[courseId] || require('../assets/images/course1.png');
    }

    const loadAllCourses = async () => {
        try {
            setLoading(prev => ({ ...prev, allCourses: true }));
            getAllCourses().then(courses => {
                setAllCourses(courses.map(course => ({
                    ...course,
                    image: getCourseImage(course.id)
                })));
            }).catch(err => {
                console.log("Error fetching all courses:", err);
                setAllCourses(sampleAllCourses); // Fallback to sample courses on error
            });
        } catch (error) {
            console.log("Error loading all courses:", error);
        } finally {
            setLoading(prev => ({ ...prev, allCourses: false }));
        }
    };
    useEffect(() => {
        loadAllCourses();
    }, []);




    // -----------------------------------------------------------------------------
    // -------------  Course Details State & Methods -------------
    // -----------------------------------------------------------------------------



    // const [enrollment, setEnrollment] = useState(null);
    const [enrollment, setEnrollment] = useState(false);


    return (
        <DataContext.Provider
            value={{
                user, loading, setLoading,
                userDetails, setUserDetails, fetchUserDetails,
                allCourses, setAllCourses, loadAllCourses,
                getCourseImage,
                wishlistedCourses, setWishlistedCourses, fetchWishlist,
                enrollment, setEnrollment,
                rewardTasks : SampleRewardTasks,
            }}
        >
            {children}
        </DataContext.Provider>
    )
}

export default DataProvider;
